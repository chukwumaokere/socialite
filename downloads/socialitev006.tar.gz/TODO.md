https://snack.expo.io/@cokere/ keep updated

Integrate iOS Simulator or develop on MacOS

REFERENCE: https://oblador.github.io/react-native-vector-icons/

